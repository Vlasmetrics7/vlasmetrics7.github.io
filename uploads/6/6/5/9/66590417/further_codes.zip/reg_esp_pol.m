function reg_esp_pol(sigmax,sigmay,T,m)
for i=1:m
By=normrnd(0,sigmay,T,1);y=cumsum(By);
Bx=normrnd(0,sigmax,T,1);x=cumsum(Bx);

x2=x.^2;
x3=x.^3;
x4=x.^4;
x5=x.^5;
x6=x.^6;
x7=x.^7;
x8=x.^8;
x9=x.^9;
x10=x.^10;


R=ols(y,[ones(T,1),x,x2,x3,x4,x5,x6,x7,x8,x9,x10]);
Betas=R.beta;
Beta1(i)=Betas(1);
Beta2(i)=Betas(2);
Beta3(i)=Betas(3);
Beta4(i)=Betas(4);
Beta5(i)=Betas(5);
Beta6(i)=Betas(6);
Beta7(i)=Betas(7);
Beta8(i)=Betas(8);
Beta9(i)=Betas(9);
Beta10(i)=Betas(10);
TSTATS=R.tstat;
T1(i)=TSTATS(1);
T2(i)=TSTATS(2);
T3(i)=TSTATS(3);
T4(i)=TSTATS(4);
T5(i)=TSTATS(5);
T6(i)=TSTATS(6);
T7(i)=TSTATS(7);
T8(i)=TSTATS(8);
T9(i)=TSTATS(9);
T10(i)=TSTATS(10);

end

[b1y,b1x]=ksdensity(Beta1);
[b2y,b2x]=ksdensity(Beta2);
[b3y,b3x]=ksdensity(Beta3);
[b4y,b4x]=ksdensity(Beta4);
[b5y,b5x]=ksdensity(Beta5);


[t1y,t1x]=ksdensity(T1);
[t2y,t2x]=ksdensity(T2);
[t3y,t3x]=ksdensity(T3);
[t4y,t4x]=ksdensity(T4);
[t5y,t5x]=ksdensity(T5);

figure(1)
plot(b1x,b1y,'k'),hold on,plot(b2x,b2y,'g'),hold on,plot(b3x,b3y,'r'),hold on,...
    plot(b4x,b4y,'c'),hold on,plot(b5x,b5y)
hleg1 = legend('\beta_{1}','\beta_{2}','\beta_{3}','\beta_{4}','\beta_{5}');
set(hleg1,'Location','NorthWest');

figure(2)
plot(t1x,t1y,'k'),hold on,plot(t2x,t2y,'g'),hold on,plot(t3x,t3y,'r'),hold on,...
    plot(t4x,t4y,'c'),hold on,plot(t5x,t5y)
hleg1 = legend('t_{\beta_{1}}','t_{\beta_{2}}','t_{\beta_{3}}','t_{\beta_{4}}','t_{\beta_{5}}');
set(hleg1,'Location','NorthWest');

