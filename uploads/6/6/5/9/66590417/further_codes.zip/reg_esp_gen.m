function reg_esp_gen(sigmax, sigmay,T,n,m,k)

for i=1:n
avance=(100*i/n)
    [AS(i),B1S(i),VarS(i),TSA(i),TSB(i),R2S(i)]=reg_esp_sim(sigmax,sigmay,T,m,k);
    [AT(i),B1T(i),VarT(i),TTA(i),TTB(i),R2T(i)]=reg_esp_teo(sigmax,sigmay,T,m,k);
    clc;
end

[as_x,as_y]=ksdensity(AS);
[b1s_x,b1s_y]=ksdensity(B1S);
[Vs_x,Vs_y]=ksdensity(VarS);
[tas_x,tas_y]=ksdensity(TSA);
[tbs_x,tbs_y]=ksdensity(TSB);
[r2s_x,r2s_y]=ksdensity(R2S);

[at_x,at_y]=ksdensity(AT);
[b1t_x,b1t_y]=ksdensity(B1T);
[Vt_x,Vt_y]=ksdensity(VarT);
[tat_x,tat_y]=ksdensity(TTA);
[tbt_x,tbt_y]=ksdensity(TTB);
[r2t_x,r2t_y]=ksdensity(R2T);

figure(1)
subplot(211), plot(as_y,as_x), hold on, plot(at_y,at_x,'r'),title('\alpha=Op(T^{m/2})')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');
subplot(212), plot(b1s_y,b1s_x), hold on, plot(b1t_y,b1t_x,'r'),title('\beta_{1}=Op(T^{m/2-k/2})')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');

figure(2)
plot(Vs_y,Vs_x), hold on, plot(Vt_y,Vt_x,'r'),title('\sigma_{u}^{2}=Op(T^m)')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');

figure(3)
subplot(211), plot(tas_y,tas_x), hold on, plot(tat_y,tat_x,'r'),title('t_{\alpha}=Op(T^{1/2})')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');
subplot(212), plot(tbs_y,tbs_x), hold on, plot(tbt_y,tbt_x,'r'),title('t_{\beta_{1}}=Op(T^{1/2})')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');

figure(4)
plot(r2s_y,r2s_x), hold on, plot(r2t_y,r2t_x,'r'),title('R^{2}=Op(1)')
hleg1 = legend('Simulated distribution','Theoretical distribution');
set(hleg1,'Location','NorthWest');

%MONTE CARLO SIMULATIONS
function [A,B1,VarS,TSA,TSB,R2S]=reg_esp_sim(sigmax, sigmay,T,m,k)

Ux=normrnd(0,sigmax,T,1);
Uy=normrnd(0,sigmay,T,1);

y=cumsum(Uy);
x=cumsum(Ux);
ym=y.^m;
xk=x.^k;

R=ols(ym,[ones(T,1),xk]);
Betas= R.beta;
TSTATS=R.tstat;
RE=R.resid;
R2S=R.rsqr;
VarS=sum(RE.^2)/T^(m+1);
A=Betas(1)*T^(-0.5*m);
B1=Betas(2)*T^(-0.5*(m-k));

TSA=TSTATS(1)*T^(-1/2);
TSB=TSTATS(2)*T^(-1/2);

    
% THEORETICAL DISTRIBUTIONS    
function [AT,B1T,VarT,TTA,TTB,R2T]= reg_esp_teo(sigmax, sigmay,T,m,k)

By=normrnd(0,sigmay,T,1);Fiy=cumsum(By);
Bx=normrnd(0,sigmax,T,1);Fix=cumsum(Bx);
Exk=sum(Fix.^k)/(T^(0.5*(k+2)));
Eym=sum(Fiy.^m)/(T^(0.5*(m+2)));
E2xk=sum(Fix.^(2*k))/(T^(k+1));
E2ym=sum(Fiy.^(2*m))/(T^(m+1));
Eymxk=sum((Fix.^k).*(Fiy.^m))/(T^(0.5*(k+m+2)));

AT=((E2xk*Eym-Exk*Eymxk))/(E2xk-Exk^2);
B1T=((-Exk*Eym+Eymxk))/(E2xk-Exk^2);
VarT=(E2xk*E2ym-E2ym*Exk^2-E2xk*Eym^2+2*Exk*Eym*Eymxk-Eymxk^2)/(E2xk-Exk^2);

XX11 = E2xk/(E2xk-Exk^2);
XX22 = 1/(E2xk-Exk^2);
  
TTA= AT / ((VarT*XX11)^(1/2));
TTB= B1T / ((VarT*XX22)^(1/2));
 
R2T=1-(E2xk*E2ym-E2ym*Exk^2-E2xk*Eym^2+2*Exk*Eym*Eymxk-Eymxk^2)/((E2xk-Exk^2)*(E2ym - Eym^2));

 
 
 